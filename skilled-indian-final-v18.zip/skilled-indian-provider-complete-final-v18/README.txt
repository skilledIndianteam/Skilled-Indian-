Skilled Indian - Complete Website V18

Open index.html or deploy this folder to Netlify.

Changes in V18:
- Existing complete website preserved.
- Language selection remains available before entering the site.
- In-site Language button is available in the header next to the logo.
- Language picker contains only English + Indian language options.
- Registration warnings no longer mention AI-generated media; they warn only against false, misleading, fake, or incorrect photos, videos, or information.
- No other site systems were intentionally changed.
