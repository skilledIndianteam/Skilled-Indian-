# Skilled Indian Provider Android Project

This is a native Android WebView project containing the supplied Skilled Indian Provider V18 HTML application.

Open the project in Android Studio and build:
Build > Build Bundle(s) / APK(s) > Build APK(s)

The web application is in:
app/src/main/assets/index.html

The application may need internet access for external images/content referenced by the original HTML.
